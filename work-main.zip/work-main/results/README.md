#Directory for results which are solted out
