#Sample inputs to be used
